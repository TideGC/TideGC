package com.example.service;

import com.example.dao.mysql.DepartmentMapper;
import com.example.entity.Department;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 旁路缓存：Cache Aside Pattern，CAP
 * <p>
 * 读操作：
 * 1. 先读缓存。缓存有，就返回
 * 2. 缓存没有，再读书库
 * 3. 写缓存，然后返回
 * <p>
 * 写操作：
 * 1. 先写数据库
 * 2. 再删缓存
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DepartmentService {

    private final DepartmentMapper departmentMapper;
    private final StringRedisTemplate stringRedisTemplate;
    private final ValueOperations<String, String> valueOperations;
    private final ObjectMapper defaultMapper;


    @SneakyThrows
    public Department getDepartment(Long id) {
        Department department = null;

        log.info("1. 先读缓存。缓存有，就返回");
        String key = "Department:" + id;
        String jsonStr = valueOperations.get(key);
        if (!StringUtils.isEmpty(jsonStr)) {
            department = defaultMapper.readValue(jsonStr, Department.class);

            return department;
        }

        log.info("2. 缓存没有，再读书库");
        department = departmentMapper.selectById(id);
        Objects.requireNonNull(department, "部门不存在");

        TimeUnit.SECONDS.sleep(5);

        log.info("3. 写缓存，然后返回");
        jsonStr = defaultMapper.writeValueAsString(department);
        valueOperations.set(key, jsonStr, 30, TimeUnit.SECONDS);

        return department;
    }

    public void updateDepartment(Long id, String newName, String newLocation) {

        log.info("1. 先写数据库");
        Department department = new Department(id, newName, newLocation);
        departmentMapper.updateById(department);

        log.info("2. 再删缓存");
        String key = "Department:" + id;
        stringRedisTemplate.delete(key);
    }
}
