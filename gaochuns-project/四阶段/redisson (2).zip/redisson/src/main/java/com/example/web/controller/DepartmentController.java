package com.example.web.controller;

import com.example.entity.Department;
import com.example.service.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@RestController
@RequiredArgsConstructor
public class DepartmentController {

    private final DepartmentService departmentService;

    private final ValueOperations<String, String> valueOperations;
    private final StringRedisTemplate stringRedisTemplate;
    private final RedissonClient redissonClient;

    @GetMapping("/department/get")
    public Department getDepartment(@RequestParam("id") Long id) {

        RLock lock = redissonClient.getLock("department-cache-lock");
        lock.lock(5, TimeUnit.SECONDS);

        Department department = departmentService.getDepartment(id);

        lock.unlock();

        return department;
    }

    @PostMapping("/department/update")
    public String updateDepartment(@RequestParam("id") Long id,
                                   @RequestParam("name") String newName,
                                   @RequestParam("location") String newLocation) {

        RLock lock = redissonClient.getLock("department-cache-lock");
        lock.lock(5, TimeUnit.SECONDS);

        departmentService.updateDepartment(id, newName, newLocation);

        lock.unlock();

        return "success";
    }
}

