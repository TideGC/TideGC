package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

@SpringBootApplication
public class RedissonApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedissonApplication.class, args);
    }

    @Bean
    public ValueOperations<String, String> valueOperations(StringRedisTemplate template) {
        return template.opsForValue();
    }

    @Bean
    public ListOperations<String, String> listOperations(StringRedisTemplate template) {
        return template.opsForList();
    }
}
