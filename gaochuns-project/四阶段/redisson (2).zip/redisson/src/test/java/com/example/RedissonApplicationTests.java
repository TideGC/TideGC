package com.example;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Slf4j
@SpringBootTest
class RedissonApplicationTests {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private ValueOperations<String, String> valueOperations;

    @Autowired
    private RedissonClient redissonClient;

    @Test
    void contextLoads() throws InterruptedException {
        RLock hello = redissonClient.getLock("hello");

         // Redisson 向 Redis 发送了一段 Lua 脚本（代码），Redis 会去执行这段代码，最终向 Redis 中添加了个键值对。
        // 这个键值对的是一个 Hash 结构。键值对的键是 hello，就是上面的 getLock 方法的参数。
        // hash 结构中有一个域，域是 uuid 拼 ":" 拼当前线程的 id，域值是一个数字。
        //      key         -       filed               -       value
        //      "hello"             "uuid:线程ID"               上锁次数
        hello.lock(10, TimeUnit.SECONDS);

        Thread.sleep(5000);

        // Redisson 向 Redis 发送了一段 Lua 脚本（代码），Redis 会去执行这段代码，最终从 Redis 中删除这对键值对。
        hello.unlock();
    }

    @Test
    public void demo() throws Exception {

        /**
         * 留意一下在上一行信息打印出来之后，多久才打印下一行信息的。
         */
        for (int i = 1; i <= 5; i++) {
            final long seconds  = i;

            new Thread(() -> {
                RLock hello = redissonClient.getLock("hello");
                hello.lock();
                log.info("{}: lock success。准备睡 {} 秒，再起来释放锁", Thread.currentThread().getId(), seconds * 2);

                quietlySleep(seconds * 2, TimeUnit.SECONDS);

                hello.unlock();

                log.info("{} : release lock success。", Thread.currentThread().getId());
            }).start();
        }

        quietlySleep(60, TimeUnit.SECONDS);
    }

    // 工具方法
    public static void quietlySleep(long n, TimeUnit timeUnit) {
        try {
            timeUnit.sleep(n);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
