package com.example;

import org.junit.jupiter.api.Test;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class JvmLockTest {

    /**
     * 可重入锁：锁的所有者，可以对锁再次上锁。
     *           只要保证未来的解锁次数和上锁次数一致即可。
     */
    @Test
    public void demo() {
        Lock lock = new ReentrantLock();

        lock.lock();
        lock.lock();    // 如果是不可重入锁，这里就会“卡”住（等拿到这个锁的人释放这个锁，哪怕这个人就是你自己）
        lock.lock();
        lock.lock();
        lock.lock();

        lock.unlock();
        lock.unlock();
        lock.unlock();
        lock.unlock();
        lock.unlock();
    }
}
