package com.example;

import org.junit.jupiter.api.Test;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.concurrent.TimeUnit;

@SpringBootTest
public class RedisonLockTest {

    @Autowired
    private RedissonClient redissonClient;

    /**
     * Redisson Lock 最终会向 Redis 中添加一个 Hash 结构的键值对：
     *
     * Key: 是 redissonClient.getLock() 方法的参数字符串
     *
     * Field: uuid + : + 当前线程（执行 lock 方法的线程）的线程id
     *
     * Value: 上锁次数。lock 会导致它 +1，unlock 导致它 -1 。
     */

    @Test
    public void demo() {
        RLock hello = redissonClient.getLock("hello");

        hello.lock(); quietlySleep(2, TimeUnit.SECONDS);
        hello.lock(); quietlySleep(2, TimeUnit.SECONDS);
        hello.lock(); quietlySleep(2, TimeUnit.SECONDS);

        hello.unlock(); quietlySleep(2, TimeUnit.SECONDS);
        hello.unlock(); quietlySleep(2, TimeUnit.SECONDS);
        hello.unlock(); quietlySleep(2, TimeUnit.SECONDS);
    }

    // 工具方法
    public static void quietlySleep(long n, TimeUnit timeUnit) {
        try {
            timeUnit.sleep(n);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
