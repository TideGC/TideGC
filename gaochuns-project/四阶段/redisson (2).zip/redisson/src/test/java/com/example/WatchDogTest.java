package com.example;

import org.junit.jupiter.api.Test;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.concurrent.TimeUnit;

@SpringBootTest
public class WatchDogTest {
    @Autowired
    private RedissonClient redissonClient;

    /**
     * Watch Dog 机制是在 "未设置自动释放锁（键值对到期自动删除）" 的时候生效的。
     */
    @Test
    public void demo() {
        RLock hello = redissonClient.getLock("hello");
        hello.lock(30, TimeUnit.SECONDS);
        quietlySleep(40, TimeUnit.SECONDS);
    }

    /**
     * 1. 调用 lock 方法的时候没有给自动释放时间（键值对过期自动删除时间），默认给的是 30 秒：
     *     hello.lock() == hello.lock(30, TimeUnit.SECONDS);
     *
     * 2. 由于显示地没有给自动释放时间，所以，Watch Dog 机制就会对这个锁起作用。
     *
     * 3. 每隔 10 秒（ 30 秒的 1/3 ，默认的比例）Watch Dog 线程会给锁背后的那个键值对重置过期时间，重置为 30 秒。
     *
     * 4. 直到：要么，代码执行了 lock.unlock() 方法，把这个锁释放了，即，即把 Redis 里的那个键值对给删了；
     *          要么，整个程序正常和非正常结束，即，包括 Watch Dog 线程在内的所有线程一起玩完。
     *                这种情况下，这个 Redis 中的键值对，最多再过 30 秒也就自动到期删除了。
     *
     *********************************************************************************************************
     *
     * lock.lock();
     * 执行业务逻辑;
     * lock.unlock();
     */
    @Test
    public void demo1() {
        RLock hello = redissonClient.getLock("hello");
        hello.lock();   // 没有给自动释放时间
        quietlySleep(20, TimeUnit.SECONDS);
        hello.unlock();
        quietlySleep(20, TimeUnit.SECONDS);
    }

    // 工具方法
    public static void quietlySleep(long n, TimeUnit timeUnit) {
        try {
            timeUnit.sleep(n);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
